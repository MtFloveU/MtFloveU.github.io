//	报告注解
Vue.component('v-explan', {
	props: ['avgFlag','orderFlag','segmentFlag','subjectFlag','hlzFlag'],
	template: '<div class="report-explain"><h2>报告注解</h2><p v-if="avgFlag"><span class="bold">平均分：</span>班级或学校参与本次考试考生的平均分，代表本班或学校平均水平。</p><p v-if="hlzFlag"><span class="bold">火力值：</span>代表学生在班级/学校等范围下的竞争力，火力值共100个等级，LV1-LV100，LV100竞争力最强。</p><p v-if="orderFlag"><span class="bold">超越率：</span>超越率=（考生数-考生排名）/（考生数-1），超越率越大，证明学生总分或学科竞争力越大。</p><p v-if="segmentFlag"><span class="bold">你的位置：</span>成绩分数段分布图，{{ subjectFlag ? 5 : 10 }}分一段，显示班级/学校学生成绩分布情况。反映学生真实位置，以及所在位置的密度，认清成绩及进步空间。你所在的分数段人数越密集，进步空间越大！</p><p><span class="bold">标准分：</span>由原始分推导出来的相对地位量数，衡量进退步更科学！</p><p v-if="!subjectFlag"><span class="bold">薄弱科目诊断雷达图：</span>蓝色线代表总成绩超过多少同学，红色线代表单科超过多少同学。蓝色线面积越大代表总成绩越好。红色线上的点离中心越远，代表越优秀。红色线上的点在蓝色线外的学科在拉高总分，相反，在蓝色线内的学科在拖总分后腿。</p><p v-if="subjectFlag"><span class="bold">难度失分分析：</span>难度失分帮助学生定位学习问题，如简单题失分高，要充分重视，代表基础知识不牢或马虎，同时也代表进步空间很大！</p><p v-if="subjectFlag"><span class="bold">S-P分析模型：</span>S-P表是宏观评价和微观评价相结合的评价方式，宏观上分析一次考试班级的应答情况，微观上定量分析一个学生的学习情况。除了能考查学生考试的答题情况，还能对学生当前的心理状况、学习方法作出相应的推断。</p></div>'
});

//	成绩单
Vue.component('v-order', {
	props: ['datas','classOrderShow','schoolOrderShow','unionOrderShow','njVip','lkVip','examTypeStr','subjectId','showYsf','scoreShow','levelShow'],
	template: '<div><h1 class="para-title">成绩单<span>成绩只代表现在，正视真实自我</span></h1><div class="ml30"><table class="tb-score"><tr><th width="16%"></th><th v-if="showYsf&&scoreShow">原始分</th><th v-if="scoreShow">成绩</th><th v-if="showLevel">等级</th><th v-if="classOrderShow">班排名</th><th v-if="schoolOrderShow">校排名</th><th v-if="unionOrderShow">{{ examTypeStr }}排名</th></tr><tr v-for="order in datas" v-if="order.id == subjectId || subjectId == -100"><td>{{ order.name }}</td><td v-if="showYsf&&scoreShow">{{ order.paperScore }}</td><td v-if="scoreShow">{{ order.score }}</td><td v-if="showLevel">{{ order.level }}</td><td v-if="classOrderShow">{{ order.classOrder }}</td><td v-if="schoolOrderShow"><v-touch @tap="callVip"><span v-if="njVip" class="no-vip-icon"></span></v-touch><span v-if="!njVip">{{order.schoolOrder}}</span></td><td v-if="unionOrderShow"><v-touch @tap="callVip"><span v-if="lkVip" class="no-vip-icon"></span></v-touch><span v-if="!lkVip">{{order.unionOrder}}</span></td></tr></table></div></div>',
	methods: {
		callVip: function () {wishApp.callVip();}
	},
	computed:{
		filter:function(){
			if(this.subjectId=="-100"){
				return this.datas;
			}
			var datass=[];
			for(var i in this.datas){
				var item = this.datas[i];
				if(item.id==this.subjectId){
					datass.push(item);
				}
			}
			return datass;
		},
		showLevel(){
			var show=false;
			for(var i in this.filter){
				var item = this.filter[i];
				if(item.level!=""){
					show=true;
				}
			}
			return show;
		}
	}
});

//分数差距
Vue.component('v-gap', {
	props: ["datas","topShow","avgShow","subjectName","fscjVip","hlzVip","desc","hlzShow","scoreShow"],
	template: '<div><p class="model-title">{{ subjectName }}分数差距</p><div class="ml30"><table class="tb-score"><tr><th width="16%"></th><th>考生数</th><th v-if="topShow">最高分</th><th v-if="avgShow">平均分</th><th v-if="hlzShow">火力值</th></tr><tr v-for="gap in datas"><td>{{ gap.name }}</td><td>{{ gap.num }}</td><td v-if="topShow"><v-touch @tap="callVip"><span v-if="fscjVip" class="no-vip-icon"></sapn></v-touch><span v-if="!fscjVip">{{gap.top}}</span></td><td v-if="avgShow"><v-touch @tap="callVip"><span v-if="fscjVip" class="no-vip-icon"></span></v-touch><span v-if="!fscjVip">{{gap.avg}}</span></td><td v-if="hlzShow"><v-touch @tap="callVip"><span v-if="hlzVip" class="no-vip-icon"></span></v-touch><span v-if="!hlzVip">{{gap.FV}}</span></td></tr></table></div><p class="summary"><span v-if="scoreShow">{{ desc }}</span></p></div>',
	methods: {callVip: function() {wishApp.callVip();}},
});

//	各难度丢分
Vue.component('v-dif', {
	props: ["datas","dtzdVip"],
	template: '<div><p class="space-title">难度失分分析</p><div class="ml30 bd"><table class="tb-score"><tr><th width="17%"></th><th width="21%">题量</th><th width="21%">分值</th><th width="21%">丢分</th><th>得分率</th></tr><tr v-for="lose in datas"><td>{{ lose.title }}</td><td>{{ lose.num }}</td><td>{{ lose.total }}</td><td v-if="dtzdVip"><v-touch @tap="callVip"><span class="no-vip-icon"></span></v-touch><td v-if="!dtzdVip">{{lose.lose}}</td><td v-if="dtzdVip"><v-touch @tap="callVip"><span class="no-vip-icon"></span></td><td v-if="!dtzdVip">{{lose.rate}}</td></tr></table></div></div>',
	methods: {callVip: function () {wishApp.callVip();}} 
});
//	答题对比分析
Vue.component('v-rate', {
	props: ["datas","dtzdVip","examType","examTypeStr","dqFlag","scoreShow","questionRateShow"],
	template: '<div><p class="space-title">答题对比分析</p><div class="ml30 bd"><table class="tblist"><tr><th width="11%">题号</th><th width="23%">我的得分率</th><th width="22%" v-if="questionRateShow!=0">班得分率</th><th width="22%" v-if="!dqFlag&&(questionRateShow==1||questionRateShow==2)">校得分率</th><th v-if="examType != 0 && !dqFlag && questionRateShow==1">{{ examTypeStr }}得分率</th></tr><tr v-for="(rate,index) in datas"><template v-if="index < 3"><td v-if="rate.bqFlag"><span class="bold">{{ rate.title }}</span></td><td v-else>{{ rate.title }}</td><td><span v-if="scoreShow || !rate.bqFlag">{{ rate.scoreRate }}</span><span v-else>-</span></td><td v-if="questionRateShow!=0"><v-touch @tap="callVip"><span v-if="dtzdVip" class="no-vip-icon"></span></v-touch><span v-if="!dtzdVip">{{rate.classScoreRate}}</span></td><td v-if="!dqFlag&&(questionRateShow==1||questionRateShow==2)"><v-touch @tap="callVip"><span v-if="dtzdVip" class="no-vip-icon"></span></v-touch><span v-if="!dtzdVip">{{rate.schoolScoreRate}}</span></td><td v-if="examType != 0 && !dqFlag && questionRateShow==1"><v-touch @tap="callVip"><span v-if="dtzdVip" class="no-vip-icon"></span></v-touch><span v-if="!dtzdVip">{{rate.unionScoreRate}}</span></td></template></tr></table></div></div>',
	methods: {callVip: function () {wishApp.callVip();}} 
});
//	待补习知识点
Vue.component('v-knowledge', {
	props: ["datas","brdVip","examType","examTypeStr","dqFlag","questionRateShow"],
	template: '<div><p class="space-title">待补习知识点</p><div class="ml30 bd"><table class="tblist"><tr><th width="17%">知识点</th><th width="23%">我的得分率</th><th width="19%" v-if="questionRateShow!=0">班得分率</th><th v-if="!dqFlag&&(questionRateShow==1||questionRateShow==2)" width="19%">校得分率</th><th v-if="examType != 0 && !dqFlag && questionRateShow==1">{{ examTypeStr }}得分率</th></tr><tr v-for="(knowledge, index) in datas" v-if="!brdVip || (brdVip && index < 1)"><td class="normal-style">{{ knowledge.name }}</td><td>{{ knowledge.scoreRate }}%</td><td v-if="questionRateShow!=0"><v-touch @tap="callVip"><span v-if="brdVip" class="no-vip-icon"></span></v-touch><span v-if="!brdVip">{{knowledge.classScoreRate}}%</span></td><td v-if="!dqFlag&&(questionRateShow==1||questionRateShow==2)"><v-touch @tap="callVip"><span v-if="brdVip" class="no-vip-icon"></span></v-touch><span v-if="!brdVip">{{knowledge.schoolScoreRate}}%</span></td><td v-if="examType != 0 && !dqFlag && questionRateShow==1"><v-touch @tap="callVip"><span v-if="brdVip" class="no-vip-icon"></span></v-touch><span v-if="!brdVip">{{knowledge.unionScoreRate}}%</span></td></tr></table></div></div>',
	methods: {callVip: function () {wishApp.callVip();}} 
});


