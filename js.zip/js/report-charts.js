var charts = {
	growChart: null,
	dqGrowChart: null,
	segmentChart: null,
	weekChart: null,
	qtcChart: null,
	pkChart:null,
	drawDqGrow: function(target, xData, seriesData, pointX, pointY){
		var spaceNum = 6;
		if(xData.length > spaceNum){
			var space =	parseInt(100 / (parseInt(xData.length / spaceNum) + 1));
			var start = 0;
			for(var x = 0; x < xData.length; x++){
				if(xData[x] == pointX){
					break;
				}else{
					start++;
				}
			}
			start = (start / spaceNum) * space;
		}else{
			start = 0;
			space = 100;
			for(var i = xData.length - 1; i < spaceNum; i++){
				xData.push("");
			}
		}

		var growOption = {
		    grid: {
		    	top: "10%",
		    	bottom: "30%",
		    	left: "15%",
		    	right: "10%"
		    },
			xAxis: {
				type: 'category',
				data: xData,
				boundaryGap: false,
				splitLine:{
					show: true
				},
				axisLabel: {
					interval: 0,
					rotate: 35,
					fontSize: 10,
					textStyle : {
						color : '#000'
					}
				},
				axisTick: {
		           show: false
		       },
		       axisLine:{
		    	   show:true,
		           onZero: false,
		           lineStyle:{
		        	   color: '#55acef',
		        	   width: 1,
		        	   type: 'solid',
		           }
		       }
			},
		    yAxis: {
		    	type: 'value',
		    	axisLabel: {
					fontSize: 11,
					textStyle : {
						color : '#000'
					}
		    	},
		    	axisTick: {
		            show: false
		        },
		        axisLine:{
		        	show:true,
		        	onZero:true,
		        	lineStyle:{
		        		color: '#55acef',
		        		width: 1,
		        		type: 'solid'
		        	}
		        },
		        inverse:true
		    },
		    dataZoom: {
		    	type: 'inside',
		    	zoomOnMouseWheel:false,
		    	moveOnMouseMove: true,
		    	// moveOnMouseWheel:false,
		    	preventDefaultMouseMove: false,
		    	start: start,
		    	end: start + space
		    },
		    series: [{
		        data: seriesData,
		        type: 'line',
		        symbolSize: 1,
		        clipOverflow :false,
	            itemStyle: {
					normal: {
						lineStyle:{
							color:'#2a8ad4',
							width:1
						}
					}
				},		
		        label: {
		        	show: true,
		        	fontSize:10,
		        	color:'#000'
		        },
		        markPoint: { 
		            symbol: 'diamond',
		            symbolSize: 8,
		            itemStyle:{
			            color: '#fe931f'
		            },
		        	data: [{
		        		coord: [pointX, pointY]
		            }]
		        }
		    }]	
		};
		if(charts.growChart == null){
			charts.growChart = echarts.init(document.getElementById(target));
		}
		charts.growChart.setOption(growOption, true);
	},
	drawGrow: function(target, xData, seriesData, pointX, pointY){
		var growOption = {
		    grid: {
		    	top: "3%",
		    	bottom: "15%",
		    	left: "10%",
		    	right: "5%"
		    },
			xAxis: {
				type: 'category',
				data: xData,
				boundaryGap: false,
				splitLine:{
					show: true
				},
				axisLabel: {
					interval: 0,
					fontSize: 11,
					textStyle : {
				　　		color : '#000'
				　　}
				},
				axisTick: {
		           show: false
		       },
		       axisLine:{
		        　　　　show:true,
		        　　　　onZero:true,
		        　　　　lineStyle:{
			        　　　　color: '#55acef',
			        　　　　width: 1,
			        　　　　type: 'solid'
		           },
		        　　   }

			},
		    yAxis: {
		    	type: 'value',
		    	min: 0,
		    	max: 100,
		    	splitNumber: 5,
		    	axisLabel: {
					fontSize: 11,
					textStyle : {
				　　		color : '#000'
				　　}
		    	},
		    	axisTick: {
		            show: false
		        },
		        axisLine:{
		        　　　　show:true,
		        　　　　onZero:true,
		        　　　　lineStyle:{
			        　　　　color: '#55acef',
			        　　　　width: 1,
			        　　　　type: 'solid'
		           }
		        　　   }
		    },
		    series: [{
		        data: seriesData,
		        type: 'line',
		        symbolSize: 1,
		        clipOverflow :false,
	            itemStyle: {
					normal: {
						lineStyle:{
							color:'#2a8ad4',
							width:1
						}
					}
				},		
		        label: {
		        	show: true,
		        	fontSize:10,
		        	color:'#000'
		        },
		        markPoint: { 
		            symbol: 'diamond',
		            symbolSize: 8,
		            itemStyle:{
			            color: '#fe931f'
		            },
		        	data: [{
		        		coord: [pointX, pointY]
		            }]
		        }
		    }]	
		};
		if(charts.growChart == null){
			charts.growChart = echarts.init(document.getElementById(target));
		}
		charts.growChart.setOption(growOption, true);
	},
	drawSegment: function(target, xData, seriesData, pointX, pointY){
		var spaceNum = 10;
		var space =	parseInt(100 / (parseInt(xData.length / spaceNum) + 1));
		var start = 0;
		for(var x = 0; x< xData.length; x++){
			if(xData[x] == pointX){
				break;
			}else{
				start++;
			}
		}
		start = (start / spaceNum) * space;
		
		var segmentOption = {
		    grid: {
		    	top: "10%",
		    	bottom: "18%",
		    	left:"8%",
		    	right:"8%"
		    },
			xAxis: {
				type: 'category',
				data: xData, 
				axisLabel: {
					interval: 0,
					fontSize: 10,
					rotate: 30,
					textStyle : {
				　　		color : '#000'
				　　}
				},
				axisTick: {
		            show: false
		        },
		        axisLine:{
		        　　　　show:true,
		        　　　　onZero:true,
		        　　　　lineStyle:{
			        　　　　color: '#9e9e9e',
			        　　　　width: 1,
			        　　　　type: 'solid'
		           }
		        　　   }
		    },
		    yAxis: {
		    	type: 'value',
		    	axisLabel: {
		    		fontSize: 10,
		    		textStyle : {
				　　		color : '#000'
				　　}
		    	},
		    	axisTick: {
		            show: false
		        },
		        axisLine:{
		        　　　　show:true,
		        　　　　onZero:true,
		        　　　　lineStyle:{
			        　　　　color: '#9e9e9e',
			        　　　　width: 1,
			        　　　　type: 'solid'
		           }
		        　　   }
		    },
		    dataZoom: {
		    	type: 'inside',
		    	zoomOnMouseWheel:false,
		    	moveOnMouseMove: true,
		    	// moveOnMouseWheel:false,
		    	preventDefaultMouseMove: false,
		    	start: start,
		    	end: start + space
		    },
		    series: [{
		        data: seriesData,
		        type: 'bar',
		        barWidth: 15,
		        clipOverflow :false,
	            itemStyle: {
	            	color: "#2a8ad4"
				},		
		        markPoint: { 
		            symbol: 'pin',
		            symbolSize: 15,
		        	data: [{
		        		coord: [pointX, pointY]
		            }]
		        }
		    }]	
		};
		if(charts.segmentChart == null){
			charts.segmentChart = echarts.init(document.getElementById(target));
		}
		charts.segmentChart.resize();
		charts.segmentChart.setOption(segmentOption, true);
	},
	drawWeek: function(target, week, orderShow){	
		var weekOption = {};
		if(week.subjects.length > 2){
			weekOption = {
			    radar: {
			        name: {
			            textStyle: {
			                color: '#000'
			           }
			        },
			        indicator: week.indicator,
			        radius: "70%",
			        nameGap: 8
			    },
			    series: [{
					type: 'radar',
					symbolSize: 1,
					data: [
					   {
						   value:week.subjects,
						   name:"单科",
						   label:{
							   show: true,
							   color: "#fe931f",
							   formatter: function(params){
									var val = params['value'];
									return val + (orderShow ? "%" : "");
							   }
						   },
						   lineStyle:{
							   color: "#fe931f",
							   width:1
						   },
						   itemStyle:{
							   color: "#fe931f"
						   }			   
					   },
					   {
						   value:week.total,
						   name:"全科",
						   lineStyle:{
							   color: "#2a8ad4",
							   type:"dashed",
							   width:1
						   },
						   itemStyle:{
							   color: "#2a8ad4"
						   }
					   }
					]
			    }]
			};
		}else{
			var datas = [], xData = [], total = week.total.length > 0 ? week.total[0] : 0;
			for(var i = 0; i < week.subjects.length; i ++){
				datas.push(week.subjects[i]);
			}
			for(var i = 0; i < week.indicator.length; i ++){
				xData.push(week.indicator[i].name);
			}
			weekOption = {
			    grid: {
			    	top: "5%",
			    	bottom: "15%",
			    	left: "10%",
			    	right: "10%"
			    },
				xAxis: {
					type: 'category',
					data: xData,
					axisLabel: {
						fontSize: 11,
						textStyle : {
					　　		color : '#000'
					　　}
					},
					axisTick: {
					   show: false
					}
				},
			    yAxis: {
			    	type: 'value',
			    	axisLabel: {
						fontSize: 11,
						textStyle : {
					　　		color : '#000'
					　　}
			    	},
			    	axisTick: {
			            show: false
			        },
			    	max: 100
			    },
			    series: [{
			        data: datas,
			        type: 'bar',
			        symbolSize: 1,
			        barWidth:25,
		            itemStyle: {
						color:'#fe931f'			
					},		
			        label: {
						show: true,
						fontSize:10,
						color:'#000',
						position:"top",
						formatter: function(params){
							return params['value'] + (orderShow ? "%" : "");
						}
			        },
			        markLine:{
			        	lineStyle:{
			        		width:1,
							color: "#2a8ad4",
							type:"dashed"
			        	},
			        	// data:[{type:"average"}]
			        	data:[{yAxis:total}]
			        }
			    }]	
			};
		}					
		charts.weekChart = echarts.init(document.getElementById(target));
		charts.weekChart.setOption(weekOption, true);	
	},
	drawQtc: function(target, qtcs){
		var report = this.report;	
		var indicator = [], datas = [];
		if(qtcs.length == 0){
			return false;
		}
		for(var i = 0; i < qtcs.length; i++){
			indicator.push({name:qtcs[i].name,max:100});
			datas.push(qtcs[i].scoreRate);
		}
		
		var qtcOption = {
		    radar: {
		        name: {
		            textStyle: {
		                color: '#000'
		           },
		           formatter : function(value) {
						if (value != undefined) {
							var l = value.length;
							if (l > 4) {
								return value.substr(0, 4) + "...";
							}
							return value;
						}
						return "";
		           }
		        },
		        indicator: indicator,
		        radius: "70%",
		        nameGap: 8
		    },
		    series: [{
				type: 'radar',
				symbolSize: 1,
				data: [
				   {
					   value:datas,
					   lineStyle:{
						   color: "#31c8ca",
						   type:"solid",
						   width:1
					   },
					   itemStyle:{
						   color: "#31c8ca"
					   },
					   label:{
						   show: true,
						   color: "#31c8ca",
						   formatter: function(params){
							   return params['value'] + "%";
						   }
					   }
				   }
				]
		    }]
		};
		charts.qtcChart = echarts.init(document.getElementById(target));
		charts.qtcChart.resize();
		charts.qtcChart.setOption(qtcOption, true);
	},
	drawPK: function(target, data){
		var xData = [],	seriesData = [];
		for(var sub = 0;sub< data.subjects.length; sub++) {
			xData.push(data.subjects[sub].name);
			var bar = {
				value: data.subjects[sub].score,
				label: {
					show: true,
					color: data.subjects[sub].score >= 0 ? "#52ac83":"#ef694e",
					position: data.subjects[sub].score >= 0 ? "top" : "bottom",
					formatter: function(params){
						if(params['value'] == 0){
							return "平" + params['value'];
						}else{
							return params['value'] > 0 ?  "胜" + params['value'] : "负" + -params['value'];
						}
					}
				},
				itemStyle: {
					color: data.subjects[sub].score >= 0 ? "#52ac83":"#ef694e"
				}
			}
			seriesData.push(bar);
		}
		var pkOption = {
			grid: {
				top: "10%",
				bottom: "15%"
			},
			xAxis: {
				type: 'category',
				data: xData,
				axisLabel: {
					interval: 0,
					fontSize: 10,
					rotate: 30
				}
			},
			yAxis: {
				type: 'value',
				axisLabel: {
					fontSize: 10
				}
			},
			series: [{
				data: seriesData,
				type: 'bar',
				barWidth: 10,
				clipOverflow: false,
				itemStyle: {
					color: "#2a8ad4"
				}
			}]
		};
		if(charts.pkChart == null){
			charts.pkChart = echarts.init(document.getElementById(target));
		}
		charts.pkChart.resize();
		charts.pkChart.setOption(pkOption, true);	
	},
	accMul: function(arg1,arg2)
	{
		var m=0,s1=arg1.toString(), s2=arg2.toString();
		try{m+=s1.split(".")[1].length}catch(e){}
		try{m+=s2.split(".")[1].length}catch(e){}
		return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m);
	}
}